package nl.han.dea.joris.exceptions;

public class UnauthorizedException extends Exception{
}
