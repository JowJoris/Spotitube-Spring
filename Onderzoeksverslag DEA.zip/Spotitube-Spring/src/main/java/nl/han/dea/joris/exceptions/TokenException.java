package nl.han.dea.joris.exceptions;

public class TokenException extends Exception{
}
