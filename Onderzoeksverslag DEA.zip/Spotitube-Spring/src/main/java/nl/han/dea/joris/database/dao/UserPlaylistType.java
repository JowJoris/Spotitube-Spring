package nl.han.dea.joris.database.dao;

public enum UserPlaylistType {

    ADD,
    DELETE
}
